# Changelog

## 2.2.1-beta.1 (source-only)

- Fixed design of Speedhack timing: scale gameplay update delta once, remove director/scheduler double scaling.
- Added experimental TPS Bypass with configurable target 120–1000 TPS, separate from render FPS.
- Moved FPS Bypass control to Display to make room for TPS controls in Gameplay.
- Marked non-native TPS runs as modified for Alpha Hack's own safe/test mode.
- Added standalone physics accumulator tests for 216 combinations.
- **No Windows/Android build or runtime validation yet. Not a public release.**

## 2.2.0

- Previous user-supplied Windows/Android universal mod package and original source.
