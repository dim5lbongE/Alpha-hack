# Alpha Hack 2.2.1 Beta 빌드 방법

**이 ZIP은 .geode 바이너리가 아니라 GitHub Actions 자동 빌드용 소스입니다.**

1. GitHub에 새 저장소를 만들거나 기존 Alpha Hack 저장소를 엽니다.
2. 이 ZIP 파일을 압축 해제하고 **내부 파일 전체를 저장소 루트에 업로드**합니다. (`.github` 폴더도 포함)
3. 저장소 `Actions` 탭 → `Build Alpha Hack Beta` → `Run workflow`를 누릅니다. 기본 브랜치가 main 또는 master라면 push만 해도 빌드가 시작됩니다.
4. 성공하면 실행 기록 하단의 `Artifacts` → `Alpha-Hack-2.2.1-beta-universal`을 다운로드하고 압축을 풉니다. 내부에 실제 `.geode` 파일이 있어야 합니다.
5. 직접 설치하여 Windows, Android에서 Speedhack과 TPS Bypass를 반드시 확인합니다. 테스트 전에 공개 Release로 배포하지 마세요.

- Geode SDK: `6.0.0-alpha.1` (mod.json에서 지정)
- 지원 목표: GD 2.2091, Windows x64 + Android ARM64
- 바이너리 빌드: **이 실행 환경에서는 미실시** (필수 SDK 및 크로스 컴파일 도구 없음)
- 원본 2.2.0 바이너리를 2.2.1로 개명하여 배포하지 않습니다.
- 빌드 실패 시 `Actions`의 실패한 단계 로그를 공유하면 오류를 해결할 수 있습니다.

공식 GitHub Actions: https://github.com/geode-sdk/build-geode-mod
