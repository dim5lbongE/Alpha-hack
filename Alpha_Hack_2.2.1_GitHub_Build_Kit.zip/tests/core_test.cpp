#include "../src/core.hpp"
#include <cassert>
#include <cmath>
#include <limits>
#include <iostream>

static void approx(double actual,double expected,double eps=1e-8){
 if(std::abs(actual-expected)>eps){
  std::cerr << "Expected " << expected << ", got " << actual << '\n';
  std::abort();
 }
}

// Exercise the same subdivision + fractional-tick algorithm that the Geode
// hook uses, without depending on Geometry Dash or the Geode SDK.
static void test_clock(double fps,double targetTPS,double speed){
 double remainder=0,elapsed=0,applied=0,dt=1./fps;
 const double tick=core::tpsTick(targetTPS,1.0);
 for(int frame=0;frame<static_cast<int>(fps*10);frame++){
  const double scaled=dt*speed;
  int parts=core::tpsSteps(scaled,targetTPS);
  assert(parts>=1 && parts<=48);
  for(int i=0;i<parts;i++){
   double current=core::consumeTPSDelta(scaled/parts,tick,remainder);
   assert(current>=0);
   applied+=current;
  }
  elapsed+=scaled;
 }
 // There is never more than one simulation tick of accumulated error.
 assert(applied <= elapsed + tick * 1e-6);
 assert(elapsed-applied <= tick + 1e-7);
 approx(applied+remainder,elapsed,1e-7);
}

int main(){
 assert(core::accuracy(100,25)==75.);assert(core::accuracy(1,99)==0.);assert(core::accuracy(0,0)==100.);
 for(unsigned n=1;n<500;++n){double last=100;for(unsigned bad=0;bad<=n+1;++bad){double a=core::accuracy(n,bad);assert(a>=0&&a<=last);last=a;}}
 assert(core::dirtyAfterReset(true,true,false));assert(!core::dirtyAfterReset(true,false,false));
 assert(core::dirtyAfterReset(false,false,true));assert(core::dirtyAfterReset(false,true,true));assert(!core::dirtyAfterReset(false,true,false));
 assert(core::speed(std::numeric_limits<double>::quiet_NaN())==1.);assert(core::speed(-1)==.1);assert(core::speed(99)==5.);
 assert(core::fps(0)==30.);assert(core::fps(9000)==2000.);
 assert(core::tps(std::numeric_limits<double>::infinity())==240.);assert(core::tps(1)==120.);assert(core::tps(5000)==1000.);
 assert(!core::customTPS(false,360));assert(!core::customTPS(true,240));assert(core::customTPS(true,360));
 assert(core::tpsSteps(1./60.,480)==8);assert(core::tpsSteps(1./120.,360)==3);
 assert(core::tpsSteps(9,1000)==48);assert(core::tpsSteps(-1,480)==1);
 approx(core::tpsTick(480,1),1./480.);approx(core::tpsTick(240,0.5),1./480.);
 double rest=0.;
 approx(core::consumeTPSDelta(1./120.,1./240.,rest),1./120.);
 approx(rest,0.);
 for(double fps : {30.,60.,120.,144.,240.,360.})
  for(double targetTPS : {120.,240.,360.,480.,960.,1000.})
   for(double speed : {0.1,0.5,1.,1.5,2.,5.})
    test_clock(fps,targetTPS,speed);
 std::cout << "Alpha Hack 2.2.1 physics core: PASS (216 clock combinations + baseline)\n";
}
