#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/modify/GameManager.hpp>
#include <Geode/modify/GJGameLevel.hpp>
#include <Geode/modify/LevelPage.hpp>
#include <Geode/modify/LevelTools.hpp>
#include <Geode/modify/MusicDownloadManager.hpp>
#include <Geode/modify/CCKeyboardDispatcher.hpp>
#include <Geode/modify/CCDirector.hpp>
#include "menu.hpp"
class $modify(AlphaFrame,CCDirector){
 void drawScene(){nova::hud();CCDirector::drawScene();}
};
// Global cocos2d time is deliberately left unchanged; only PlayLayer physics
// receives a scaled delta in NovaSimulation below.
class $modify(NovaKeys,CCKeyboardDispatcher){
 bool dispatchKeyboardMSG(enumKeyCodes k,bool down,bool repeat,double timestamp){
  if(k==KEY_Tab&&!nova::picker){if(down&&!repeat)nova::openMenu();return true;}
  if(nova::menu&&k==KEY_Escape){if(down&&!repeat)nova::menu->onClose(nullptr);return true;}
  return CCKeyboardDispatcher::dispatchKeyboardMSG(k,down,repeat,timestamp);
 }
};
class $modify(NovaMenu,MenuLayer){
 bool init(){
  if(!MenuLayer::init())return false;nova::load();nova::applyFPS();
  auto m=CCMenu::create();m->setPosition({0,0});addChild(m,100);
  auto l=CCLabelBMFont::create("Alpha hack","bigFont.fnt");l->setScale(.42f);l->setColor({100,220,255});
  auto b=CCMenuItemSpriteExtra::create(l,this,menu_selector(NovaMenu::onNova));b->setPosition({CCDirector::sharedDirector()->getWinSize().width-64,25});m->addChild(b);return true;
 }
 void onNova(CCObject*){nova::openMenu();}
};
class $modify(NovaPlay,PlayLayer){
 bool init(GJGameLevel* l,bool dontCreate){
  if(!PlayLayer::init(l,dontCreate))return false;nova::run={};nova::run.layer=this;nova::run.nativeTest=m_isTestMode;nova::mark();nova::sync(this);nova::lastPitch=-1;return true;
 }
 void onEnterTransitionDidFinish(){PlayLayer::onEnterTransitionDidFinish();nova::applyFPS();}
 void toggleMusicInPractice(){PlayLayer::toggleMusicInPractice();nova::sync(this);}
 void togglePracticeMode(bool p){if(p)nova::sync(this);PlayLayer::togglePracticeMode(p);}
 void destroyPlayer(PlayerObject* p,GameObject* o){
  if(nova::c.noclip&&p&&(o!=m_anticheatSpike||!m_anticheatSpike)&&!m_hasCompletedLevel){nova::mark();nova::run.hit=true;return;}
  PlayLayer::destroyPlayer(p,o);
 }
 void resetLevel(){
  if(nova::run.layer==this&&nova::run.dirty)m_isTestMode=true;
  PlayLayer::resetLevel();
  if(nova::run.layer==this){nova::run.total=0;nova::run.bad=0;nova::run.hit=false;
   nova::run.dirty=core::dirtyAfterReset(nova::run.dirty,m_isPracticeMode,nova::cheats());m_isTestMode=nova::run.nativeTest||nova::run.dirty;nova::sync(this);}
 }
 bool shouldDrawDebugHitboxes(){return nova::c.hitboxes||PlayLayer::shouldDrawDebugHitboxes();}
 void levelComplete(){nova::mark();if(nova::run.dirty)m_isTestMode=true;PlayLayer::levelComplete();}
 void onExit(){nova::pitch(1.f);PlayLayer::onExit();if(nova::run.layer==this)nova::run={};}
};
class $modify(NovaSimulation,GJBaseGameLayer){
 // Run at the configured physics tick, not the screen refresh rate. The game
 // calls this during its internal 2.2 physics loop. No fixed memory offsets or
 // binary patches are used, so the source is portable across Geode targets.
 double getModifiedDelta(float dt){
  if(nova::tpsContext.layer!=this || !core::customTPS(nova::c.tpsBypass,nova::c.tps))
   return GJBaseGameLayer::getModifiedDelta(dt);
  double remaining=m_extraDelta;
  if(m_resumeTimer < 1){
   const double part=std::max(0.,static_cast<double>(dt))/nova::tpsContext.steps;
   const double tick=core::tpsTick(nova::c.tps,m_gameState.m_timeWarp);
   const double applied=core::consumeTPSDelta(part,tick,remaining);
   m_extraDelta=remaining;
   return applied;
  }
  // Match vanilla resume-delay behavior: accumulate no new elapsed time.
  --m_resumeTimer;
  const double tick=core::tpsTick(nova::c.tps,m_gameState.m_timeWarp);
  const double applied=core::consumeTPSDelta(0.,tick,remaining);
  m_extraDelta=remaining;
  return applied;
 }
 void update(float dt){
  auto p=PlayLayer::get();
  const bool active=p&&static_cast<GJBaseGameLayer*>(p)==this&&nova::run.layer==p&&!p->m_isPaused&&!p->m_hasCompletedLevel;
  if(!active){GJBaseGameLayer::update(dt);return;}
  nova::mark();nova::run.hit=false;
  const float speed=nova::c.speedhack?static_cast<float>(nova::c.speed):1.f;
  nova::pitch(nova::c.audio?speed:1.f);
  const float scaledDT=dt*speed;
  const bool track=nova::c.noclip&&scaledDT>0&&!p->m_inResetDelay&&p->m_player1&&!p->m_player1->m_isDead;
  if(core::customTPS(nova::c.tpsBypass,nova::c.tps)&&m_started&&!m_isEditor){
   const int steps=core::tpsSteps(scaledDT,nova::c.tps);
   const auto previous=nova::tpsContext;
   nova::tpsContext={this,steps};
   for(int i=0;i<steps;++i){
    GJBaseGameLayer::update(scaledDT);
    if(track&&nova::run.layer==p){++nova::run.total;if(nova::run.hit)++nova::run.bad;}
    nova::run.hit=false;
   }
   nova::tpsContext=previous;
  }else{
   GJBaseGameLayer::update(scaledDT);
   if(track&&nova::run.layer==p){++nova::run.total;if(nova::run.hit)++nova::run.bad;}
  }
 }
};
class $modify(NovaPause,PauseLayer){
 void onPracticeMode(CCObject* s){nova::sync(PlayLayer::get());PauseLayer::onPracticeMode(s);}
};
class $modify(NovaManager,GameManager){
 bool isIconUnlocked(int id,IconType t){if(nova::c.icons&&id>0&&t!=IconType::Item)return true;return GameManager::isIconUnlocked(id,t);}
 bool isColorUnlocked(int id,UnlockType t){if(nova::c.icons&&id>=0&&(t==UnlockType::Col1||t==UnlockType::Col2))return true;return GameManager::isColorUnlocked(id,t);}
 void updateCustomFPS(){GameManager::updateCustomFPS();if(nova::c.bypass)nova::applyFPS();}
};
class $modify(NovaMainLevels,LevelPage){
 bool init(GJGameLevel* l){int coins=l?l->m_requiredCoins:0;if(l&&nova::c.levels)l->m_requiredCoins=0;bool ok=LevelPage::init(l);if(l)l->m_requiredCoins=coins;return ok;}
 void onPlay(CCObject* s){auto l=m_level;int coins=l?l->m_requiredCoins:0;if(l&&nova::c.levels)l->m_requiredCoins=0;LevelPage::onPlay(s);if(l)l->m_requiredCoins=coins;}
};
class $modify(NovaLevelData,GJGameLevel){
 void savePercentage(int percent,bool practice,int clicks,int attempts,bool valid){
  if(nova::run.layer&&nova::run.layer->m_level==this&&nova::run.dirty)return;GJGameLevel::savePercentage(percent,practice,clicks,attempts,valid);
 }
 std::string getAudioFileName(){auto p=nova::replacement(m_songID>0,m_songID>0?m_songID:m_audioTrack);return p.empty()?GJGameLevel::getAudioFileName():p;}
};
class $modify(NovaSongPaths,MusicDownloadManager){
 std::string pathForSong(int id){auto p=nova::replacement(true,id);return p.empty()?MusicDownloadManager::pathForSong(id):p;}
};
class $modify(NovaBuiltInSongs,LevelTools){
 static std::string getAudioFileName(int id){auto p=nova::replacement(false,id);return p.empty()?LevelTools::getAudioFileName(id):p;}
};
$on_mod(Loaded){
 nova::load();listenForAllSettingChanges([](std::string_view,std::shared_ptr<SettingV3>){nova::load();nova::mark();nova::applyFPS();});
 log::info("Alpha hack 2.2.1 beta loaded. Tab opens the menu.");
}
