#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
namespace core {
inline double speed(double n) { return std::isfinite(n)?std::clamp(n,.1,5.):1.; }
inline double fps(double n) { return std::isfinite(n)?std::clamp(n,30.,2000.):240.; }
// The vanilla 2.2 physics clock is 240 TPS. Keep custom values bounded so a
// single lag spike cannot make the game perform thousands of simulation calls.
inline double tps(double n) { return std::isfinite(n)?std::clamp(n,120.,1000.):240.; }
inline bool customTPS(bool enabled, double n) { return enabled && std::abs(tps(n)-240.)>0.001; }
inline int tpsSteps(double dt,double n,int maximum=48) {
 if(!std::isfinite(dt) || dt<=0) return 1;
 return std::clamp(static_cast<int>(std::ceil(std::min(dt,1.)*tps(n))),1,maximum);
}
inline double tpsTick(double n,double timeWarp) {
 auto warp=std::isfinite(timeWarp)?std::clamp(timeWarp,0.01,1.0):1.0;
 return warp/tps(n);
}
// Accumulate fractional physics steps, carrying unused time into the next
// update; prevents systematic time drift at non-integer FPS/TPS ratios.
inline double consumeTPSDelta(double subDelta,double tick,double& remainder) {
 if(!std::isfinite(subDelta)||subDelta<0 || !std::isfinite(tick)||tick<=0) return 0.;
 double pending=std::max(0.,remainder)+subDelta;
 double ticks=std::floor((pending+tick*1e-8)/tick);
 double applied=ticks*tick;
 remainder=std::max(0.,pending-applied);
 return applied;
}
inline double accuracy(uint64_t n,uint64_t bad) { return n?100.*(n-std::min(n,bad))/n:100.; }
inline bool dirtyAfterReset(bool previous,bool practice,bool enabled) { return enabled||(practice&&previous); }
}
