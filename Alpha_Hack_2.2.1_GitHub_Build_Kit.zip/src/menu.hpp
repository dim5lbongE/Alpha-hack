#pragma once
#include "runtime.hpp"
namespace nova {
class Menu:public Popup {
 CCNode* body=nullptr;CCMenu* controls=nullptr;TextInput* number=nullptr;TextInput* songID=nullptr;CCLabelBMFont* message=nullptr;
 Slider* speedSlider=nullptr;CCLabelBMFont* speedLabel=nullptr;
 bool songCustom=true,resumeOnClose=false;PlayLayer* pausedLayer=nullptr;int page=0;
 struct Toggle{const char* key;const char* title;};std::vector<Toggle> toggles;
 void label(std::string const& s,float x,float y,float scale=.35f) {
  auto l=CCLabelBMFont::create(s.c_str(),"bigFont.fnt");l->setScale(scale);l->setPosition({x,y});l->setColor({240,247,255});body->addChild(l);
 }
 void button(std::string const& s,float x,float y,int tag,SEL_MenuHandler callback,float width=185) {
  auto bg=CCScale9Sprite::create("square02_small.png");bg->setContentSize({width,27});bg->setColor({92,128,168});
  auto l=CCLabelBMFont::create(s.c_str(),"bigFont.fnt");l->setScale(std::min(.39f,(width-12)/std::max(1.f,l->getContentSize().width)));l->setPosition({width/2,13.5});bg->addChild(l);
  auto b=CCMenuItemSpriteExtra::create(bg,this,callback);b->setTag(tag);b->setPosition({x,y});controls->addChild(b);
 }
 void toggle(char const* key,char const* title,float x,float y) {
  int i=static_cast<int>(toggles.size());toggles.push_back({key,title});
  button(fmt::format("{} {}",Mod::get()->getSettingValue<bool>(key)?"[ON]":"[OFF]",title),x,y,i,menu_selector(Menu::onToggle));
 }
 void status(char const* s){if(message)message->setString(s);}
 std::optional<int> target() {
  try{auto s=songID->getString();size_t used=0;int n=std::stoi(s,&used);if(used!=s.size()||n<0||(songCustom&&n==0))throw std::invalid_argument("id");return n;}
  catch(...){status("Enter a valid song ID first.");return std::nullopt;}
 }
public:
 static Menu* create(bool resume,PlayLayer* p) {
  auto m=new Menu();m->resumeOnClose=resume;m->pausedLayer=p;
  if(!m->init(450,290,"GJ_square01.png")){delete m;return nullptr;}
  m->autorelease();m->setTitle("Alpha hack / 2.2.1 Beta","bigFont.fnt",.55f,18);m->m_bgSprite->setColor({105,145,185});
  m->body=CCNode::create();m->m_mainLayer->addChild(m->body,3);
  m->controls=CCMenu::create();m->controls->setPosition({0,0});m->m_mainLayer->addChild(m->controls,101);m->render();return m;
 }
 void render() {
  body->removeAllChildren();controls->removeAllChildren();toggles.clear();number=nullptr;songID=nullptr;message=nullptr;speedSlider=nullptr;speedLabel=nullptr;
  char const* tabs[]={"Gameplay","Display","Unlocks","Songs"};
  for(int i=0;i<4;++i)button((page==i?"> ":"")+std::string(tabs[i]),62+i*108,244,100+i,menu_selector(Menu::onPage),102);
  if(page==0){
   toggle("enabled","Practice music",116,210);toggle("noclip","Noclip",334,210);
   toggle("speedhack","Speedhack",116,177);toggle("audio-speed","Speed audio",334,177);
   toggle("hitboxes","Hitboxes",116,144);toggle("tps-bypass","TPS bypass",334,144);
   label("TPS",49,109);
   number=TextInput::create(110,"240");number->setCommonFilter(CommonFilter::Uint);number->setString(fmt::format("{:.0f}",c.tps));number->setScale(.8f);number->setPosition({140,109});body->addChild(number);
   button("Apply TPS",270,109,0,menu_selector(Menu::onTPS),132);label("120 - 1000",385,109,.27f);
   speedLabel=CCLabelBMFont::create(fmt::format("Speed {:.2f}x",c.speed).c_str(),"bigFont.fnt");speedLabel->setScale(.34f);speedLabel->setPosition({105,73});body->addChild(speedLabel);
   speedSlider=Slider::create(this,menu_selector(Menu::onSpeedSlide),.7f);speedSlider->setPosition({284,73});speedSlider->setValue(static_cast<float>((c.speed-.1)/4.9));body->addChild(speedSlider);
   label("0.10x",214,49,.25f);label("5.00x",354,49,.25f);
   label("Speed / TPS / noclip runs use test mode.",225,23,.28f);
  }else if(page==1){
   toggle("show-fps","Show FPS",116,205);toggle("show-clock","Show clock",334,205);
   toggle("cheat-indicator","Cheat indicator",116,166);toggle("show-accuracy","Noclip accuracy",334,166);
#ifdef GEODE_IS_WINDOWS
   toggle("vertical-sync","Vertical Sync",116,127);
#else
   label("VSync: Android managed",116,127,.29f);
#endif
   toggle("smooth-fix","Smooth Fix",334,127);
   toggle("fps-bypass","FPS bypass",116,88);
   label("FPS target",78,50);
   number=TextInput::create(100,"240");number->setCommonFilter(CommonFilter::Uint);number->setString(fmt::format("{:.0f}",c.fps));number->setScale(.8f);number->setPosition({225,50});body->addChild(number);
   button("Apply",350,50,0,menu_selector(Menu::onFPS),100);
   label("VSync can limit FPS to display refresh.",225,23,.27f);
  }else if(page==2){
   toggle("unlock-icons","Unlock icons",116,203);toggle("unlock-levels","Main levels",334,203);
   label("Icons + colors become selectable locally.",225,157,.34f);label("Reopen the garage after changing icon unlock.",225,132,.30f);
   label("Main levels: bypass the secret-coin entry requirement.",225,98,.28f);label("No coins or completed levels are added to your save.",225,73,.28f);label("Reopen level selection to refresh lock visuals.",225,41,.29f);
  }else{
   label("Replace a song with a local audio file",225,207,.38f);
   button(songCustom?"Custom song (NG ID)":"Built-in song (audio ID)",137,170,0,menu_selector(Menu::onSongType),226);
   songID=TextInput::create(125,"Song ID");songID->setCommonFilter(CommonFilter::Uint);songID->setScale(.8f);songID->setPosition({337,170});body->addChild(songID);
   if(auto p=PlayLayer::get();p&&p->m_level)songID->setString(std::to_string(songCustom?p->m_level->m_songID:p->m_level->m_audioTrack));
   button("Choose audio file",116,128,0,menu_selector(Menu::onChoose));button("Restore original",334,128,0,menu_selector(Menu::onRestore));
   message=CCLabelBMFont::create("MP3 / OGG / WAV / FLAC","chatFont.fnt");message->setScale(.46f);message->setPosition({225,92});body->addChild(message);
   label("The current level's song ID is filled in automatically.",225,62,.27f);label("Shared song ID = shared replacement. Reopen the level.",225,43,.26f);label("Original files stay untouched. Song triggers keep their IDs.",225,24,.25f);
  }
 }
 void onPage(CCObject* s){if(picker)return;page=s->getTag()-100;if(page==3){if(auto p=PlayLayer::get();p&&p->m_level)songCustom=p->m_level->m_songID>0;}render();}
 void onToggle(CCObject* s){auto t=toggles.at(s->getTag());auto m=Mod::get();m->setSettingValue<bool>(t.key,!m->getSettingValue<bool>(t.key));load();mark();sync(PlayLayer::get());applyFPS();render();}
 void onSpeedSlide(CCObject*){
  if(!speedSlider)return;
  double n=std::round(core::speed(.1+4.9*speedSlider->getValue())*100.)/100.;
  Mod::get()->setSettingValue<double>("speed",n);
  Mod::get()->setSettingValue<bool>("speedhack",true);load();mark();
  for(size_t i=0;i<toggles.size();++i)if(std::string_view(toggles[i].key)=="speedhack"){
   if(auto item=controls->getChildByTag(static_cast<int>(i)))if(auto l=findFirstChildRecursive<CCLabelBMFont>(item,[](auto){return true;}))l->setString("[ON] Speedhack");
  }
  if(speedLabel)speedLabel->setString(fmt::format("Speed {:.2f}x",c.speed).c_str());
 }
 void onFPS(CCObject*){
  try{auto s=number->getString();size_t used=0;auto n=std::stoll(s,&used);if(used!=s.size()||n<30||n>2000)throw std::invalid_argument("range");Mod::get()->setSettingValue<int64_t>("fps-target",n);load();applyFPS();render();}
  catch(...){FLAlertLayer::create("FPS","Enter a whole number from 30 to 2000.","OK")->show();}
 }
 void onTPS(CCObject*){
  try{
   auto s=number->getString();size_t used=0;auto n=std::stoll(s,&used);
   if(used!=s.size()||n<120||n>1000)throw std::invalid_argument("range");
   Mod::get()->setSettingValue<int64_t>("tps-target",n);
   load();mark();render();
  }catch(...){FLAlertLayer::create("TPS","Enter a whole number from 120 to 1000.","OK")->show();}
 }
 void onSongType(CCObject*){songCustom=!songCustom;render();}
 void onChoose(CCObject*){
  auto id=target();if(!id||picker)return;
  picker=true;retain();const bool custom=songCustom;const int song=*id;
  async::spawn(file::pick(file::PickMode::OpenFile,file::FilePickOptions{
   .filters={{"Audio files",{"*.mp3","*.ogg","*.wav","*.flac"}}}
  }),[this,custom,song](file::PickResult result){
   picker=false;
   if(result.isOk()&&result.unwrap().has_value())importSong(fs::path(result.unwrap().value().native()),custom,song);
   else if(result.isErr())status("Could not open file picker.");
   release();
  });
 }
 void importSong(fs::path const& src,bool custom,int id){
  try{
   auto ext=src.extension().string();std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
   if(ext!=".mp3"&&ext!=".ogg"&&ext!=".wav"&&ext!=".flac")throw std::runtime_error("type");
   if(!fs::file_size(src)||fs::file_size(src)>512ULL*1024*1024)throw std::runtime_error("size");
   auto dir=fs::path(Mod::get()->getSaveDir().native())/"songs";fs::create_directories(dir);
   auto dst=dir/fs::path(fmt::format("{}-{}",songKey(custom,id),std::chrono::system_clock::now().time_since_epoch().count()));dst+=ext;fs::copy_file(src,dst);
   FMOD::Sound* test=nullptr;auto result=FMODAudioEngine::sharedEngine()->m_system->createStream(utf8(dst).c_str(),FMOD_DEFAULT,nullptr,&test);
   if(result!=FMOD_OK){fs::remove(dst);throw std::runtime_error("decode");}test->release();
   auto key=songKey(custom,id);auto value=utf8(dst);Mod::get()->setSavedValue(key,value);songs[key]=value;status("Song linked. Leave and reopen the level.");
  }catch(...){status("Import failed: check audio, file size or disk space.");}
 }
 void onRestore(CCObject*){auto id=target();if(!id)return;auto key=songKey(songCustom,*id);Mod::get()->setSavedValue(key,std::string());songs[key]="";status("Original restored. Leave and reopen the level.");}
 void onClose(CCObject* s) override {
  if(picker)return;
  bool resume=resumeOnClose;auto p=pausedLayer;if(menu==this)menu=nullptr;Popup::onClose(s);
  if(resume&&p&&PlayLayer::get()==p){auto scene=CCDirector::sharedDirector()->getRunningScene();if(scene){auto pause=findFirstChildRecursive<PauseLayer>(scene,[](auto){return true;});if(pause)pause->onResume(nullptr);}}
 }
 ~Menu() override {if(menu==this)menu=nullptr;}
};
void openMenu(){
 if(picker)return;if(menu){menu->onClose(nullptr);return;}load();auto p=PlayLayer::get();bool resume=false;
 if(p&&!p->m_isPaused&&!p->m_hasCompletedLevel){p->pauseGame(false);resume=p->m_isPaused;}
 menu=Menu::create(resume,p);if(menu)menu->show();
}
}
