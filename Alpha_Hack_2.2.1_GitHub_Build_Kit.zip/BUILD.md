# Alpha Hack 2.2.1 Beta — 빌드 지침

기존 2.2.0의 소스 구성과 Geode 내부 ID를 그대로 유지합니다.

## 필요한 것

- Geometry Dash **2.2091**에 대응하는 Geode SDK **v6.0.0-alpha.1**
- Geode CLI **4.0.0 이상** (Geode v6 릴리스 요구 사항)
- CMake 3.25 이상 + C++23 컴파일러
- Windows x64: Visual Studio C++/Windows SDK (또는 동등한 Geode 지원 도구)
- Android arm64-v8a: Geode v6용 Android NDK 및 도구 체인

## Windows 예시 (PowerShell)

```powershell
$env:GEODE_SDK = 'C:\\path\\to\\geode-sdk'
cmake -S . -B build-win -G 'Visual Studio 17 2022' -A x64
cmake --build build-win --config RelWithDebInfo
```

## Android arm64-v8a 예시

```bash
export GEODE_SDK=/path/to/geode-sdk
export ANDROID_NDK_HOME=/path/to/android-ndk
cmake -S . -B build-android -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-23 \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build-android
```

실제 Geode v6/플랫폼별 도구 체인에 따라 설정 추가가 필요할 수 있습니다. Windows DLL과 Android SO를 모두 얻은 다음에만 Geode 규격에 맞춰 `.geode` 패키지를 만들어야 합니다. **기존 2.2.0 바이너리를 섞어 2.2.1로 표기하면 안 됩니다.**

## 알고리즘 테스트 (SDK 불필요)

```bash
clang++ -std=c++23 -O2 -Wall -Wextra -Werror tests/core_test.cpp -o core_test
./core_test
```

## 실기기 배포 전 필수 확인

- 게임 진입/종료 및 메뉴 조작이 크래시 없이 가능한지
- Speedhack 0.5× / 1.0× / 2.0× 가 실제 플레이 시간에 반영되는지
- TPS 240 / 360 / 480에서 측정되는 물리 업데이트가 기대값과 일치하는지
- TPS 해제 시 240으로 복귀하는지
- FPS와 TPS를 동시에 설정해도 서로 덮어쓰지 않는지
- 메인 레벨/연습 모드/사망/재시작/일시정지 시 잔여시간 오류가 없는지
- 기록 저장 차단 및 치트 표시 유지가 정상인지
- Windows와 Android에서 각각 검증하는지
